<?php get_header(); ?>
<!-- ===================END-HEADER============= -->

<div id="main-content-wp" class="detail-product-page">
    <div class="wp-inner clearfix">

        <?php get_sidebar(); ?>
        <!-- -----------End-Sidebar---------- -->

        <div id="content" class="float-right">
            <?php if (!empty($product)) { ?>
                <div class="session" id="info-product-wp">
                    <div class="session-detail clearfix">
                        <div class="thumb float-left">
                            <img src="<?= $product['product_thumb']; ?>" alt="">
                        </div>
                        <div class="detail float-right">
                            <h3 class="title"><?= $product['product_title']; ?></h3>
                            <p class="price"><?= currency_format($product['price']); ?></p>
                            <p class="product-code">Mã sản phẩm: <span><?= $product['code']; ?></span></p>
                            <div class="desc-short">
                                <h5>Mô tả sản phẩm</h5>
                                <p><?= $product['product_desc']; ?></p>
                            </div>
                            <div class="num-order-wp">
                                <span>Số lượng:</span>
                                <input type="text" id="num-order" name="num-order" value="1">
                                <a href="<?= $product['url_add_cart']; ?>" class="add-to-cart">Thêm giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="session" id="desc-wp">
                    <div class="session-head">
                        <h3 class="session-title">Chi tiết sản phẩm</h3>
                    </div>
                    <div class="session-detail">
                    <?= $product['product_content']; ?>
                    </div>
                </div>
            <?php }else{ ?>
                <p class="text-danger">Sản phẩm bạn đang tìm kiếm không tồn tại</p>
                <?php } ?>

        </div>
        <!-- -----------End-Content---------- -->
    </div>
</div>
<!-- ===================END-MAIN CONTENT============= -->

<?php get_footer(); ?>