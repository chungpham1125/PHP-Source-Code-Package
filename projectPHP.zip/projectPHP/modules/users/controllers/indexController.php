<?php

function construct()
{
    load_model('index');
};

function mainAction()
{
    $list_user = get_list_user();
    // show_array($list_user);
    $data['list_user'] = $list_user;
    load_view('index', $data);
}


function editAction()
{
    $id = (int)$_GET['id'];
    $info_user = get_info_user_by_id($id);
    show_array($info_user);
}

function loginAction()
{
    global $username, $errors;
    // Gọi model vào để xử lý database
    load_model('login');

    if (isset($_POST['btn_login'])) {
        // Tạo biến $errors trống tượng chưng cho việc chưa có lỗi gì
        $errors = array();

        // Kiểm tra username
        $check_username = is_username($_POST['username']);
        if (!$check_username['status']) {
            $errors['username'] = $check_username['message'];
        } else {
            $username = $_POST['username'];
        }

        // Kiểm tra password
        $check_password = is_password($_POST['password']);
        if (!$check_password['status']) {
            $errors['password'] = $check_password['message'];
        } else {
            $password = md5($_POST['password']);
        }

        // Kiểm tra nếu không xảy ra lỗi gì thì gửi username lên database
        if (empty($errors)) {
            if ($is_user = check_login($username, $password)) {
                // Nếu tài khoản tồn tại thì thông tin tài khoản sẽ lưu vào biết trên
                $_SESSION['is_login'] = true;
                $_SESSION['user_login'] = $is_user['user_id'];

                // Kiểm tra xen người dùng có muốn nhớ tài khoản không?
                if(isset($_POST['remember_me']) && ($_POST['remember_me'] == 'yes')){
                    setcookie('is_login', true, time()+3600, '/');
                    setcookie('user_login', $is_user['user_id'], time()+3600, '/');
                }

                redirect_to('?mod=home');
            } else {
                // Xử lý nếu sai
                $errors['account'] = "Tên đăng nhập hoặc mật khẩu không chính xác";
            }
        }
    }


    // $data['errors'] = $errors ?? '';
    // $data['account'] = $account ?? '';
    load_view('login');
}

function registerAction()
{
    load_view('register');
}

function logoutAction()
{
    unset($_SESSION['is_login']);
    unset($_SESSION['user_login']);

    setcookie('is_login', true, time() - 3600, '/');
    setcookie('user_login', '', time() - 3600, '/');

    redirect_to('?mod=users&controller=index&action=login');
}
