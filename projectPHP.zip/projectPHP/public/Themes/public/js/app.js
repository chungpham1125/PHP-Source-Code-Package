$(document).ready(function() {
    $('#btn-respon').click(function(event) {
        $('#site').toggleClass('show-respon-menu');
        event.stopPropagation();
    });
    $('#container').click(function() {
        if ($('#site').hasClass('show-respon-menu')) {
            $('#site').removeClass('show-respon-menu');
        }
    });
});