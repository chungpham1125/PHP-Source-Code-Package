<?php get_header(); ?>
<!-- ===================END-HEADER============= -->

<div id="main-content-wp" class="category-product-page">
    <div class="wp-inner clearfix">

        <?php get_sidebar(); ?>
        <!-- -----------End-Sidebar---------- -->

        <div id="content" class="float-right">
            <div class="session list-cat">
                <div class="session-head">
                    <h3 class="session-title"><?= $cat_info['cat_title']; ?></h3>
                    <p class="session-desc">Có <?= count($list_product); ?> sản phẩm trong mục này</p>
                </div>
                <div class="session-detail">
                    <?php if (!empty($list_product)) { ?>
                        <ul class="list-item clearfix">
                            <?php foreach ($list_product as $item) { ?>
                                <li>
                                    <a href="<?= $item['url']; ?>" title="" class="thumb">
                                        <img src="<?= $item['product_thumb']; ?>" alt="">
                                    </a>
                                    <a href="<?= $item['url']; ?>" class="title"><?= $item['product_title']; ?></a>
                                    <p class="price"><?= currency_format($item['price']); ?></p>
                                </li>
                            <?php } ?>
                        </ul>
                    <?php } else { ?>
                        <p class="text-danger">Dữ liệu không tồn tại</p>
                    <?php } ?>
                </div>
            </div>
            <div id="pagenavi-wp" class="pagenavi-wp session">
                <div class="session-detail">
                    <!-- Thanh Phân Trang -->
                    <?php if($str_pagging){ print $str_pagging; }; ?>
                    
                </div>
            </div>
        </div>
        <!-- -----------End-Content---------- -->
    </div>
</div>
<!-- ===================END-MAIN CONTENT============= -->

<?php get_footer(); ?>