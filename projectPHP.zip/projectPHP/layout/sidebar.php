<?php
function set_active($module, $id = 0)
{
    $current_module = isset($_GET['mod']) ? $_GET['mod'] : 'home';
    if ($module != 'home') {
        $cat_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($module == $current_module && $id == $cat_id)
            print 'class="active"';
    } else {
        if ($module == $current_module)
            print 'class="active"';
    }
}
?>
<div id="sidebar" class="float-left">
    <nav id="main-menu-wp">
        <ul class="list-item">
            <li <?= set_active('home'); ?>><a href="Trang-chu" title="Trang chủ">Trang chủ</a></li>
            <li <?= set_active('pages', 1); ?>><a href="Gioi-thieu-1" title="Giới thiệu">Giới thiệu</a></li>
            <li <?= set_active('products', 1); ?>><a href="Danh-muc/Mobile-1" title="Điện thoại">Điện thoại</a></li>
            <li <?= set_active('products', 2); ?>><a href="Danh-muc/Laptop-2" title="Laptop">Laptop</a></li>
            <li <?= set_active('products', 3); ?>><a href="Danh-muc/Tablet-3" title="Máy tính">Máy tính bảng</a></li>
            <li <?= set_active('pages', 2); ?>><a href="Lien-he-2" title="Liên hệ">Liên hệ</a></li>
        </ul>
    </nav>
</div>