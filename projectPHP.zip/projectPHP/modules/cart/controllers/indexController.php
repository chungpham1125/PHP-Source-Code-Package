<?php

function construct()
{
    // Thư viện hàm xử lý chức năng giỏ hàng 
    load('lib', 'cart');
};

//  SHOW GIỎ HÀNG
function indexAction()
{
    // Lấy danh sách sp trong giỏ hàng
    $list_product_cart = get_list_cart();

    // Lấy thông tin đơn hàng
    $order_info = get_info_order();

    $data = array(
        'list_product_cart' => $list_product_cart,
        'order_info' => $order_info,
    );
    // show_array($_SESSION);
    load_view('index', $data);
}

//  THÊM SẢN PHẨM VÀO GIỎ HÀNG
function addAction()
{
    // Load file model của products vào để lấy những hàm xửa lý product!
    require MODULESPATH . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'indexModel.php';

    $id = (int)$_GET['id']; // Lấy id sản phẩm trên url
    // Thên sản phẩm vào giỏ hàng
    add_cart($id);

    // Chuyển hướng đến trang show giỏ hàng
    redirect_to('?mod=cart');
}

//  CẬP NHẬT GIỎ HÀNG
function updateAction()
{
    update_cart();
    // Chuyển hướng đến trang show giỏ hàng
    redirect_to('?mod=cart');
}

// CẬP NHẬT GIỎ HÀNG = AJAX
function updateAjaxAction()
{
    $id = (int)$_POST['id'];
    $new_qty = (int)$_POST['qty'];

    if (array_key_exists($id, $_SESSION['cart']['buy'])) {
        $_SESSION['cart']['buy'][$id]['qty'] = $new_qty;
        $sub_total = $new_qty * $_SESSION['cart']['buy'][$id]['price'];
        $_SESSION['cart']['buy'][$id]['sub_total'] = $sub_total;
        update_info_order();
        $total = $_SESSION['cart']['info']['total'];
        $num_order = $_SESSION['cart']['info']['num_order'];

        $result = array(
            'sub_total' => currency_format($sub_total),
            'total' => currency_format($total),
            'num_order' => $num_order,
        );

        echo json_encode($result);
    }
}

//  XÓA SẢN PHẨM TRONG GIỎ HÀNG
function deleteAction()
{

    // Xoá sản phẩm có id tương ứng
    $id = (int)$_GET['id'];
    delete_cart($id);

    // Chuyển hướng đến trang show giỏ hàng
    redirect_to('?mod=cart');
}

//  XÓA TOÀN BỘ GIỎ HÀNG
function deleteAllAction()
{
    // Nếu không có tham số thì xóa toàn bộ giỏ hàng
    delete_cart();

    // Chuyển hướng đến trang show giỏ hàng
    redirect_to('?mod=cart');
}

//  THANH TOÁN
function checkoutAction()
{
    // Lấy danh sách sp trong giỏ hàng
    $list_product_cart = get_list_cart();
    // Lấy thông tin hóa đơn
    $info_order = get_info_order();

    $data = array(
        'list_product_cart' => $list_product_cart,
        'info_order' => $info_order,
    );
    load_view('checkout', $data);
}


function thankAction()
{
    load('lib', 'mail');

    if (isset($_POST['btn_checkout'])) {
        $errors = array();

        // CUSTOMER'S INFO
        if (empty($_POST['fullname'])) {
            $errors['fullname'] = 'Quý khách vui lòng điền họ & tên';
        } else {
            $send_to['fullname'] = $_POST['fullname'];
        }

        if (empty($_POST['email'])) {
            $errors['email'] = 'Quý khách vui lòng cung cấp địa chỉ email';
        } else {
            $send_to['mail_address'] = $_POST['email'];
        }

        if (empty($_POST['address'])) {
            $errors['address'] = 'Quý khách vui lòng cung cấp địa chỉ nhận hàng';
        } else {
            $send_to['address'] = $_POST['address'];
        }

        if (empty($_POST['tel'])) {
            $errors['tel'] = 'Quý khách vui lòng cung cấp thông tin liên lạc';
        } else {
            $send_to['tel'] = $_POST['tel'];
        }
        $send_to['note'] = $_POST['note'];

        // ORDER INFO
        $order['num_order'] = $_POST['num_order'];
        $order['products'] = '';
        $order['total'] = $_POST['total'];
        if(!empty($_POST['products'])){
            foreach($_POST['products'] as $item){
                $order['products'] .= "<li>{$item['title']}: {$item['qty']} chiếc; tổng: {$item['sub_total']}</li>\n";
            }
        }
        $order_info = "
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset='UTF-8'>
        <title>Xác Nhậc Đơn Hàng</title>
        </head>
        <body>
        <div id='order'>
        <div id='customer-info'>
            <p>Xin chân thành cảm ơn anh/chị đã tin tưởng mua hàng chỗ chúng tôi.</p>
            <h4>Xác Nhận Thông Tin Khách Hàng</h4>
            <p>Họ & tên: {$send_to['fullname']}</p>
            <p>Địa chỉ: {$send_to['address']}</p>
            <p>Địa Chỉ Email: {$send_to['mail_address']}</p>
            <p>Số liên lạc: {$send_to['tel']}</p>
            <p>Chú thích:{$send_to['note']}</p>
        </div>
        <div id='order-info'>
            <h4>Xác Nhận Thông Tin Hóa Đơn</h4>
            <p>Tổng cộng: {$order['num_order']} sản phẩm</p>
            <ul>
                {$order['products']}
            </ul>
            <p>Tổng hóa đơn: {$order['total']}</p>
        </div>
        </div>
        </body>
        </html>
        ";

        if(empty($errors)){
            $contents = array(
                'subject' => 'Xac Nhan Don Hang',
                'body' => $order_info,
                'body_non_html' => ''
            );
            send_mail($send_to, $contents);
        }
    }

    load_view('thank');
}
?>