<?php

function get_page_by_id($id){
    $result = db_fetch_row("SELECT * FROM `tbl_pages` WHERE `id` = {$id}");
    if(!empty($result)){
        return $result;
    }else{
        return false;
    }
}



?>