<?php

function construct(){
    load('lib', 'pagging');
}

function indexAction(){
    load_model('index');

    // Lấy thông tin của danh mục
    $cat_id = (int)$_GET['id'];
    $cat_info = get_cat_by_id($cat_id);

    // PHÂN TRANG - PAGGING
    // - Một trang chỉ hiển thị 4 sản phẩm
    $num_per_page = 4; // Số bài trên một trang
    // Lấy danh sách sản phẩm thuộc danh mục
    $list_product = get_list_product_by_cat_id($cat_id, $num_per_page);

    // Thanh Phân Trang
    $current_page_url = '?mod=products';
    $str_pagging = get_pagging($cat_id, $num_per_page, $current_page_url);


    $data = array(
        'cat_info' => $cat_info,
        'list_product' => $list_product,
        'str_pagging' => $str_pagging,
    );
    load_view('index', $data);
}

function detailAction(){
    load_model('index');

    // Lấy thông tin sản phẩm theo id;
    $id = (int)$_GET['id'];
    $product = get_product_by_id($id);

    $data['product'] = $product;
    load_view('detail', $data);
}

?>