
<?php get_header(); ?>
            <!-- ===================END-HEADER============= -->

            <div id="main-content-wp">
                <div class="wp-inner clearfix">
                    <?php get_sidebar(); ?>
                    <!-- -----------End-Sidebar---------- -->

                    <div id="content" class="float-right">
                        <div class="session" id="detail-news-wp">
                            <div class="session-head">
                                <h3 class="session-title"><?= $page_info['page_title']; ?></h3>
                            </div>
                            <div class="session-detail">
                                <p class="create-date"><?= $page_info['created_at']; ?></p>
                                <div class="content-news">
                                <?= $page_info['page_content']; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- -----------End-Content---------- -->
                </div>
            </div>
            <!-- ===================END-MAIN CONTENT============= -->

            <?php get_footer(); ?>