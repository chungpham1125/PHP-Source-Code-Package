<?php get_header(); ?>
<!-- ===================END-HEADER============= -->

<div id="main-content-wp">
    <div class="wp-inner clearfix">

        <?php get_sidebar(); ?>
        <!-- -----------End-Sidebar---------- -->

        <div id="content" class="float-right">
            <div id="list-cat-<?= $mobile_cat_id; ?>" class="session list-cat">
                <div class="session-head">
                    <h3 class="session-title"><a href="<?= $mobile_cat['url'] ?>"><?= $mobile_cat['cat_title']; ?></a></h3>
                </div>
                <div class="session-detail">
                    <?php if (!empty($list_mobile)) { ?>
                        <ul class="list-item clearfix">
                            <?php foreach ($list_mobile as $item) { ?>
                                <li>
                                    <a href="<?= $item['url']; ?>" title="" class="thumb">
                                        <img src="<?= $item['product_thumb']; ?>" alt="">
                                    </a>
                                    <a href="<?= $item['url']; ?>" class="title"><?= $item['product_title']; ?></a>
                                    <p class="price"><?= currency_format($item['price']); ?></p>
                                </li>
                            <?php } ?>
                        </ul>
                    <?php } else { ?>
                        <p class="text-danger">Khổng có sản phẩm</p>
                    <?php } ?>
                </div>
            </div>
            <!-- Mobile Pagenavigation -->
            <?php if ($mobile_pagging) { ?>
                <div id="pagenavi-wp-<?= $mobile_cat_id; ?>" class="pagenavi-wp js-pagenavi-wp session clearfix">
                    <div class="session-detail float-right">
                        <?= $mobile_pagging; ?>
                    </div>
                </div>
            <?php } ?>

            <div id="list-cat-<?= $laptop_cat_id; ?>" class="session list-cat">
                <div class="session-head">
                    <h3 class="session-title"><a href="<?= $laptop_cat['url'] ?>"><?= $laptop_cat['cat_title']; ?></a></h3>
                </div>
                <div class="session-detail">
                    <?php if (!empty($list_laptop)) { ?>
                        <ul class="list-item clearfix">
                            <?php foreach ($list_laptop as $item) { ?>
                                <li>
                                    <a href="<?= $item['url']; ?>" title="" class="thumb">
                                        <img src="<?= $item['product_thumb']; ?>" alt="">
                                    </a>
                                    <a href="<?= $item['url']; ?>" class="title"><?= $item['product_title']; ?></a>
                                    <p class="price"><?= currency_format($item['price']); ?></p>
                                </li>
                            <?php } ?>
                        </ul>
                    <?php } else { ?>
                        <p class="text-danger">Khổng có sản phẩm</p>
                    <?php } ?>
                </div>
            </div>
            <!-- Laptop Pagenavigation -->
            <?php if ($laptop_pagging) { ?>
                <div id="pagenavi-wp-<?= $laptop_cat_id; ?>" class="pagenavi-wp js-pagenavi-wp session clearfix">
                    <div class="session-detail float-right">
                        <?= $laptop_pagging; ?>
                    </div>
                </div>
            <?php } ?>
            <div id="list-cat-<?= $tablet_cat_id; ?>" class="session list-cat">
                <div class="session-head">
                    <h3 class="session-title"><a href="<?= $tablet_cat['url'] ?>"><?= $tablet_cat['cat_title']; ?></a></h3>
                </div>
                <div class="session-detail">
                    <?php if (!empty($list_tablet)) { ?>
                        <ul class="list-item clearfix">
                            <?php foreach ($list_tablet as $item) { ?>
                                <li>
                                    <a href="<?= $item['url']; ?>" title="" class="thumb">
                                        <img src="<?= $item['product_thumb']; ?>" alt="">
                                    </a>
                                    <a href="<?= $item['url']; ?>" class="title"><?= $item['product_title']; ?></a>
                                    <p class="price"><?= currency_format($item['price']); ?></p>
                                </li>
                            <?php } ?>
                        </ul>
                    <?php } else { ?>
                        <p class="text-danger">Khổng có sản phẩm</p>
                    <?php } ?>
                </div>
            </div>
            <!-- Tablet Pagenavigation -->
            <?php if ($tablet_pagging) { ?>
                <div id="pagenavi-wp-<?= $tablet_cat_id; ?>" class="pagenavi-wp js-pagenavi-wp session clearfix">
                    <div class="session-detail float-right">
                        <?= $tablet_pagging; ?>
                    </div>
                </div>
            <?php } ?>
        </div>
        <!-- -----------End-Content---------- -->
    </div>
</div>
<!-- ===================END-MAIN CONTENT============= -->

<?php get_footer(); ?>
<!-- ===================END-FOOTER============= -->