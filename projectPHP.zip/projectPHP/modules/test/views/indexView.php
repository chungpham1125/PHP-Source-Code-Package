<?php

print show($string);


?>