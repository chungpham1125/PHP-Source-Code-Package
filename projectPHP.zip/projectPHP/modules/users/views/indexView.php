<?php
// show_array($list_user);
$gender = array(
    'male' => 'Nam',
    'female' => 'Nữ',
);
?>
<html>

<head>
    <title>Danh sách thành viên</title>
</head>

<body>
    <h1>Danh sách thành viên</h1>
    <table>
        <thead>
            <tr>
                <th>Stt</th>
                <th>Họ & tên</th>
                <th>Tuổi</th>
                <th>Giới tính</th>
            </tr>
        </thead>

        <?php if (!empty($list_user)) {
            $temp = 0;
        ?>
            <tbody>
                <?php foreach ($list_user as $user) {
                    $temp++;
                ?>
                    <tr>
                        <td><?= $temp; ?></td>
                        <td><?= $user['fullname']; ?></td>
                        <td><?= $user['age']; ?></td>
                        <td><?= $gender[$user['gender']]; ?></td>
                    </tr>
                <?php } ?>

            </tbody>
        <?php } ?>

    </table>
</body>

</html>