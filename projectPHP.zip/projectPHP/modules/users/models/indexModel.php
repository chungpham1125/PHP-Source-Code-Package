<?php

function get_list_user(){
    $list_user = db_fetch_array('SELECT * FROM `tbl_users`');
    return $list_user;
}

function get_info_user_by_id($id){
    $info_user = db_fetch_row("SELECT * FROM `tbl_users` WHERE `user_id` = {$id}");
    return $info_user;
}


?>