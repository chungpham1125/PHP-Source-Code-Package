<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <base href="<?= base_url(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="public/css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/css/reset.css">
    <link rel="stylesheet" href="public/css/Fontawesome/css/all.min.css">
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="public/css/responsive.css">
    <title>Unitop Store</title>
</head>

<body>
    <div id="site">
        <div id="container">
            <div id="header-wp">
                <div class="wp-inner clearfix">
                    <a href="Trang-chu" id="logo" class="float-left">UNITOP STORE</a>
                    <div id="btn-respon" class="float-right"><i class="fas fa-bars"></i></div>
                    <div id="cart-wp" class="float-right">
                        <a href="?mod=cart" id="btn-cart">
                            <span id="icon"><img src="public/images/icon-cart.png" alt=""></span>
                            <?php if (isset($_SESSION['cart']) && ($_SESSION['cart']['info']['num_order']>0)) { ?>
                                <span id="num"><?= $_SESSION['cart']['info']['num_order']; ?></span>
                            <?php } ?>
                        </a>
                    </div>
                </div>
            </div>