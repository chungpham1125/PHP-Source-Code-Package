<?php get_header(); ?>
<!-- ===================END-HEADER============= -->

<div id="main-content-wp" class="cart-page">
    <div class="session" id="breadcrumb-wp">
        <div class="wp-inner">
            <div class="session-detail">
                <h3 class="title">Giỏ hàng</h3>
            </div>
        </div>
    </div>
    <div id="wrapper" class="wp-inner clearfix">
        <!-- Kiểm tra xem trong giỏ hàng có sp không -->
        <?php if (!empty($list_product_cart)) { ?>
            <div class="session" id="info-cart-wp">
                <div class="session-detail table-responsive">
                    <form action="?mod=cart&action=update" method='POST'>
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>Mã sản phẩm</td>
                                    <td>Ảnh sản phẩm</td>
                                    <td>Tên sản phẩm</td>
                                    <td>Giá sản phẩm</td>
                                    <td>Số lượng</td>
                                    <td colspan='2'>Thành tiền</td>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Duyệt mảng giỏ hàng -->
                                <?php foreach ($list_product_cart as $item) { ?>
                                    <tr>
                                        <td><?= $item['code']; ?></td>
                                        <td>
                                            <a href="<?= $item['url']; ?>" class="thumb">
                                                <img src="<?= $item['product_thumb']; ?>" alt="">
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?= $item['url']; ?>" class="name-product"><?= $item['product_title']; ?></a>
                                        </td>
                                        <td><?= currency_format($item['price']); ?></td>
                                        <td>
                                            <input type="number" min='1' max='9' name="qty[<?= $item['id']; ?>]" value="<?= $item['qty']; ?>" data-id='<?= $item['id']; ?>' class="num-order js-num-order">
                                        </td>
                                        <td id='sub-total-<?= $item['id']; ?>'><?= currency_format($item['sub_total']); ?></td>
                                        <td>
                                            <a href="<?= $item['delete_url']; ?>" class="delete-product"><i class="far fa-trash-alt"></i></a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="7">
                                        <div class="clearfix">
                                            <p id="total-price" class="float-right">Tổng giá: <span><?= currency_format($order_info['total']); ?></span></p>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="7">
                                        <div class="clearfix">
                                            <div class="float-right">
                                                <!-- <a href="?mod=cart&controller=index&action=update" id="update-cart">Cập nhật giỏ hàng</a> -->
                                                <input type="submit" name="btn_update" value="Cập nhật giỏ hàng" id="update-cart">
                                                <a href="?mod=cart&controller=index&action=checkout" id="checkout-cart">Thánh toán</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
                <div class="session" id="action-cart-wp">
                    <div class="session-detail">
                        <p class="title">Click vào <span>"Cập nhật giỏ hàng"</span> để cập nhật số lượng <span>0</span> để xóa sản phẩm khỏi giỏ hàng. Nhấn vào thanh toán để hoàn tất mua hàng.</p>
                        <a href="?" id="buy-more">Mua tiếp</a>
                        <a href="?mod=cart&action=deleteAll" id="delete-cart">Xóa toàn bộ giỏ hàng</a>
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <p class="text-danger">Không có sản phẩm nào trong giỏ hàng. Quay lại <a href="?">Trang chủ</a> để mua hàng.</p>
        <?php } ?>
    </div>
</div>
<!-- ===================END-MAIN CONTENT============= -->

<?php get_footer(); ?>