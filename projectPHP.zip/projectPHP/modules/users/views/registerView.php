<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?= base_url(); ?>">
    <title>Form Login</title>
    <link rel="stylesheet" href="public/css/reset.css">
    <link rel="stylesheet" href="public/css/login.css">
    <link rel="stylesheet" href="public/css/register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body id="register">
    <div id="wrapper">
        <form action="" method='POST' class="form-login">
            <h2 class="form-header">FORM ĐĂNG KÝ</h2>
            <div class="form-group">
                <div class="form-icon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                <input type="text" name="username" <?php if(!empty($username)){ ?>value="<?= $username; ?>"<?php } ?> class="form-input username" placeholder="Tên đăng nhập">
            </div>
            <?php if(isset($errors['username'])){ ?>
            <p class="form-error"><?= $errors['username']; ?></p>
            <?php } ?>
            <div class="form-group">
                <div class="form-icon"><i class="fa fa-key" aria-hidden="true"></i></div>
                <input type="password" name="password" class="form-input password js-password" placeholder="Mật khẩu">
                <div class="eye">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <?php if(isset($errors['password'])){ ?>
            <p class="form-error"><?= $errors['password']; ?></p>
            <?php } ?>
            <input type="submit" name='btn_login' value="ĐĂNG KÝ" class="form-submit">
        </form>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="public/js/app.js"></script>

</html>