<?php

function construct(){
    load('lib', 'pagging');
    // if(isset($_COOKIE['is_login']) && ($_COOKIE['is_login'] == true)){
    //     $_SESSION['is_login'] = $_COOKIE['is_login'];
    //     $_SESSION['user_login'] = $_COOKIE['user_login'];
    // }
};

function indexAction(){
    /*
        HIỂN THỊ THÔNG TIN USER ĐÃ LOGIN
    */
    load_model('index');
    // $user_info = get_user_info_by_id($_SESSION['user_login']);
    // $data['user_info'] = $user_info;

    // Load file model của products vào để lấy những hàm xửa lý product!
    require MODULESPATH . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'indexModel.php';
    
    // Lấy thông tin danh mục
    $mobile_cat = get_cat_by_id(1);
    $laptop_cat = get_cat_by_id(2);
    $tablet_cat = get_cat_by_id(3);
    
    // Lấy danh sách sản phẩm của mỗi danh mục
    // - Số lượng bài viết được phép hiển thị
    $num_per_page = 4;
    $list_mobile = get_list_product_by_cat_id(1, $num_per_page);
    $list_laptop = get_list_product_by_cat_id(2, $num_per_page);
    $list_tablet = get_list_product_by_cat_id(3, $num_per_page);

    // THANH PHÂN TRANG
    // - Đường dẫn của trang hiện tại
    $current_base_url = '?mod=home';

    // 1.Điện Thoại
    // Id của danh mục điện thoại
    $mobile_cat_id = 1;
    $mobile_pagging = get_pagging($mobile_cat_id, $num_per_page, $current_base_url);

    // 2.Laptop
    // Id của danh mục Laptop
    $laptop_cat_id = 2;
    $laptop_pagging = get_pagging($laptop_cat_id, $num_per_page, $current_base_url);

    // 3.Máy tính bản
    // Id của danh mục máy tính bảng
    $tablet_cat_id = 3;
    $tablet_pagging = get_pagging($tablet_cat_id, $num_per_page, $current_base_url);


    $data = array(
        // Id danh mục
        'mobile_cat_id' => $mobile_cat_id,
        'laptop_cat_id' => $laptop_cat_id,
        'tablet_cat_id' => $tablet_cat_id,

        // Danh mục
        'mobile_cat' => $mobile_cat,
        'laptop_cat' => $laptop_cat,
        'tablet_cat' => $tablet_cat,

        // Danh sách sản phẩm
        'list_mobile' => $list_mobile,
        'list_laptop' => $list_laptop,
        'list_tablet' => $list_tablet,

        // Thanh phân trang
        'mobile_pagging' => $mobile_pagging,
        'laptop_pagging' => $laptop_pagging,
        'tablet_pagging' => $tablet_pagging,
    );

    load_view('index', $data);
}

function paggingAjaxAction(){
    // Load file model của products vào để lấy những hàm xửa lý product!
    require MODULESPATH . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'indexModel.php';
    
    load_model('paggingAjax');

    // LOAD BẢN GHI BẰNG AJAX
    $cat_id = $_POST['cat_id'];  // Id của danh mục
    $page = $_POST['page'];  // Chỉ số của trang hiện tại
    $list_product = get_list_product_by_cat_id($cat_id, 4, $page);
    $html_list_product = get_html_list_products($list_product);

    // LOAD THANH PHÂN TRANG BẰNG AJAX
    $base_url = "?mod=home";
    $html_pagging = get_pagging($cat_id, 4, $base_url, $page);
    
    $result = array(
        'html_list_product' => $html_list_product,
        'html_pagging' => $html_pagging
    );

    echo json_encode($result);
    
}



?>