<?php

// HÀM TẠO CHUỖI HTML CHO DANH SÁCH SẢN PHẨM THEO DANH MỤC
/*
<?php if (!empty($list_mobile)) { ?>
        <ul class="list-item clearfix">
            <?php foreach ($list_mobile as $item) { ?>
                <li>
                    <a href="<?= $item['url']; ?>" title="" class="thumb">
                        <img src="<?= $item['product_thumb']; ?>" alt="">
                    </a>
                    <a href="<?= $item['url']; ?>" class="title"><?= $item['product_title']; ?></a>
                    <p class="price"><?= currency_format($item['price']); ?></p>
                </li>
            <?php } ?>
        </ul>
    <?php } else { ?>
        <p class="text-danger">Khổng có sản phẩm</p>
    <?php } ?>
*/
function get_html_list_products($list_products){
    if(!empty($list_products)){
        $html_list_products = '<ul class="list-item clearfix">';
        foreach($list_products as $item){
            $html_list_products .= "
            <li>
                    <a href=\"{$item['url']}\" title=\"\" class=\"thumb\">
                        <img src=\"{$item['product_thumb']}\" alt=\"\">
                    </a>
                    <a href=\"{$item['url']}\" class=\"title\">{$item['product_title']}</a>
                    <p class=\"price\">".currency_format($item['price'])."</p>
                </li>
            ";
        }
        $html_list_products .= '</ul>';
    }else{
        $html_list_products = '<p class="text-danger">Khổng có sản phẩm</p>';
    }

    return $html_list_products;
    
}

// HÀM TẠO CHUỖI HTML CHO THANH PHÂN TRANG CỦA DANH MỤC SẢN PHẨM




?>