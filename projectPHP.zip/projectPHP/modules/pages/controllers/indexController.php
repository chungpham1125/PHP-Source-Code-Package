<?php
function construct(){
};

function detailAction(){
    load_model('index');

    $page_id = (int)$_GET['id'];

    $page_info = get_page_by_id($page_id);
    $page_info['created_at'] = substr($page_info['created_at'],0,10);//2021-10-22 11:00:40 => 2021-10-22

    $data['page_info'] = $page_info;

    load_view('detail', $data);
}

?>