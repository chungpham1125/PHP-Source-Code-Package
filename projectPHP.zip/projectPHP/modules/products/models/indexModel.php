<?php

/*
    * HÀM LẤY THÔNG TIN DANH MỤC THEO ID
    * Kết quả: Trả về danh mục khớp với id, hoặc nếu không có danh mục khớp với id thì trả vể false
    * $result {
        'id' => 'id danh mục',
        'cat_title' => 'Tên danh mục'
    }
*/
function get_cat_by_id($id)
{
    $result = db_fetch_row("SELECT * FROM `tbl_product_cats` WHERE `id` = {$id}");
    if (!empty($result)) {
        // Thêm trường url để trỏ đến trang danh mục sản phầm
        $result['url'] = "?mod=products&id={$id}";
        return $result;
    } else {
        return false;
    }
}

/*

    * HÀM LẤY DANH SÁCH SẢN PHẨM THEO ID DANH MỤC
    * Kết quả: Trả về danh sách những sản phẩm có cat_id tương ứng, Nếu không có thì trả về false
    * $result {
        1 => array {
            'id' => 'Id của sản phẩm',
            'product_title' => 'Tên của sản phẩm',
            'price' => 'Giá của sản phẩm',
            'code' => 'Mã sản phẩm',
            'product_desc' => 'Mô tả ngắn về sản phẩm',
            'product_thumb' => 'Đường đẫn của hình ảnh sản phầm',
            'product_content' => 'Chi tiết về sản phẩm',
            'cat_id' => 'Mã id của danh mục sản phẩm đó thuộc về'
        }
        2 => array {
            'id' => 'Id của sản phẩm',
            'product_title' => 'Tên của sản phẩm',
            'price' => 'Giá của sản phẩm',
            'code' => 'Mã sản phẩm',
            'product_desc' => 'Mô tả ngắn về sản phẩm',
            'product_thumb' => 'Đường đẫn của hình ảnh sản phầm',
            'product_content' => 'Chi tiết về sản phẩm',
            'cat_id' => 'Mã id của danh mục sản phẩm đó thuộc về'
        }
        .
        .
        ....
    }
*/
function get_list_product_by_cat_id($cat_id, $num_per_page = 0, $page = 0)
{
    $limit = ""; // Ban đầu mặc định là không hạn chế số bản ghi

    // Nếu Có Hạn Chế Số Bản Ghi    
    if ($num_per_page > 0) {
        // - Trang hiện tại
        if($page == 0){
            $page = 1;
            if ((isset($_GET['id'])) && ($cat_id == $_GET['id'])) {
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            }
        }
        
        // - Chỉ số của bản ghi bắt đầu của một trang
        $start = ($page - 1) * $num_per_page;
        if (($start >= 0) && ($num_per_page > 0)) {
            $limit = "LIMIT {$start}, $num_per_page";
        }
    }
    $result = db_fetch_array("SELECT * FROM `tbl_products` WHERE `cat_id` = {$cat_id} {$limit}");
    if (!empty($result)) {
        // Thêm trường url dẫn đến trang chi tiết cho mỗi sản phẩm
        foreach ($result as &$item) {
            $item['url'] = "?mod=products&controller=index&action=detail&id={$item['id']}";
        }

        return $result;
    } else {
        return false;
    }
}

/*

    * HÀM LẤY THÔNG TIN MỘT SẢN PHẨM CỤ THEO THEO ID
    * Kết quả: trả về tất cả thông tin của sản phẩm nếu nó có id khớp nhau, nếu không có id khớp thì trả về false
    * $result {
        'id' => 'Id của sản phẩm',
            'product_title' => 'Tên của sản phẩm',
            'price' => 'Giá của sản phẩm',
            'code' => 'Mã sản phẩm',
            'product_desc' => 'Mô tả ngắn về sản phẩm',
            'product_thumb' => 'Đường đẫn của hình ảnh sản phầm',
            'product_content' => 'Chi tiết về sản phẩm',
            'cat_id' => 'Mã id của danh mục sản phẩm đó thuộc về'
    }

*/
function get_product_by_id($id)
{
    $result = db_fetch_row("SELECT * FROM `tbl_products` WHERE `id` = {$id}");
    if (!empty($result)) {
        // Thêm trường url để chỏ đén chi tiết sp
        $result['url'] = "?mod=products&controller=index&action=detail&id={$id}";

        // Thêm trường url_add_cart để chỏ đến chức năng thêm giỏ hàng
        $result['url_add_cart'] = "?mod=cart&controller=index&action=add&id={$id}";
        return $result;
    } else {
        return false;
    }
}


