<?php

// THÊM SẢN PHẨM VÀO GIỎ HÀNG
/*
    * Giỏ Hàng
    * $_SESSION['cart']['buy']{
        1 => array(
            'id' => 'Id cuả sản phẩm (1)',
            'product_title' => 'Tên sản phẩm',
            'price' => 'Giá của sp',
            'code' => 'Mã sản phẩm',
            'product_thumb' => 'Ảnh minh họa sp',
            'qty' => 'Số lượng',
            'sub_total' => 'Tổng chi phi của sp = Số lượng * Giá của sp',
        ),
        2 => array(
            ...
        ),
        ....
    }
*/
function add_cart($id)
{
    $product = get_product_by_id($id); // Lấy thông tin sản phẩm tương ứng vs id
    $qty = 1; // Số lượng sản phẩm khách mua
    // Kiểm tra xem trong giỏ hàng của khách đã có sp tương tự hay chưa?
    if (isset($_SESSION['cart'])) {
        // Nếu có thì cộng số lượng khách mua vs số lượng có trong giỏ hàng
        if (array_key_exists($id, $_SESSION['cart']['buy'])) {
            $qty = $_SESSION['cart']['buy'][$id]['qty'] + $qty;
        }
    }
    $_SESSION['cart']['buy'][$id] = array(
        'id' => $id,
        'product_title' => $product['product_title'],
        'price' => $product['price'],
        'code' => $product['code'],
        'url' => $product['url'],
        'product_thumb' => $product['product_thumb'],
        'qty' => $qty,
        'sub_total' => ($qty * $product['price']),
    );

    // Cập Nhật Thông Tin Đơn Hàng
    update_info_order();
}

// CẬP NHẬT THÔNG TIN ĐƠN HÀNG
/*
    * Thông Tin Đơn Hàng
    $_SESSION['cart']['info']{
        'num_order' => 'Số lượng tất cả sp có trong giỏ hàng',
        'total' => 'Tổng chi phí tất cả sp trong giỏ hàng'
    }
*/
function update_info_order()
{
    if (!empty($_SESSION['cart'])) {
        $num_order = 0;
        $total = 0;
        foreach ($_SESSION['cart']['buy'] as $item) {
            $num_order += $item['qty'];    // Cập nhật số lượng tất cả sp trong giỏ hàng
            $total += $item['sub_total'];   // Cập nhật tổng chi phí
        }
        $_SESSION['cart']['info'] = array(
            'num_order' => $num_order,
            'total' => $total,
        );
    }
}

// HÀM LẤY DANH SÁCH SP TRONG GIỎ HÀNG
function get_list_cart()
{
    // isset($_SESSION['cart']['buy']) ? $_SESSION['cart']['buy'] : array();
    if (!empty($_SESSION['cart']['buy'])) {
        foreach($_SESSION['cart']['buy'] as &$item){
            $item['delete_url'] = "?mod=cart&controller=index&action=delete&id={$item['id']}";
        }
        return $_SESSION['cart']['buy'];
    } else {
        return false;
    }
}

//  HÀM LẤY THÔNG TIN ĐƠN HÀNG
function get_info_order()
{
    if (isset($_SESSION['cart'])) {
        return $_SESSION['cart']['info'];
    } else {
        return false;
    }
}

//  HÀM CẬP NHẬT GIỎ HÀNG
/*
    $qty = array(
        'id' => 'new_qty',
        1 => 4,
        3 => 7,
        9 => 2,
    );
*/
function update_cart()
{
    // Kiểm tra xem có phải người dùng muốn ập nhật giỏ hàng hay không?
    if (isset($_POST['btn_update'])) {
        foreach ($_POST['qty'] as $id => $new_qty) {
            $new_qty = (int)$new_qty;
            // Cập nhật số lượng mới
            $_SESSION['cart']['buy'][$id]['qty'] = $new_qty;
            // Cập nhật tổng tiền một loaị sản phẩm
            $_SESSION['cart']['buy'][$id]['sub_total'] = $_SESSION['cart']['buy'][$id]['price'] * $new_qty;
        }

        // Cập nhập lại thông tin đơn hàng
        update_info_order();
    }
}

//  HÀM XÓA SẢN PHẨM TRONG GIỎ HÀNG
function delete_cart($id = NULL){
    if(isset($id)){
        // Nếu có tham số id thì xóa sản phẩm khớp với id
        unset($_SESSION['cart']['buy'][$id]);

        // Cập nhật hóa đơn
        update_info_order();
    }else{
        // Nếu không có tham số id thì xóa toàn bộ giỏ hàng
        unset($_SESSION['cart']);

        // Cập nhật hóa đơn
        update_info_order();
    }
}
