<?php

function construct(){
    session_start();
    ob_start();
    
    load('helper', 'url');
    load('lib', 'validation_form');

    if(isset($_COOKIE['is_login']) && ($_COOKIE['is_login'] == true)){
        $_SESSION['is_login'] = $_COOKIE['is_login'];
        $_SESSION['user_login'] = $_COOKIE['user_login'];
    }

    check_is_login();
}

function indexAction(){
    $username = 'phamchung';
    $password = md5('A1talaha');
    function check_login($username, $password){
        // Kiểm tra xem tên đăng nhập có tồn tại trong database không
        $result = db_num_rows("SELECT * FROM `tbl_users` WHERE `username` = '{$username}'");
        if(!($result >= 1)){
            // Nếu không tồn tại thì giá trị sẽ trả về 0
            return false;
        }
        else{
            // Nếu tồn tại thì kiểm tra password có chính xác không;
            $result = db_fetch_row("SELECT * FROM `tbl_users` WHERE `username` = '{$username}' AND `password` = '{$password}'");
            if(empty($result)){
                return false;
            }else{
                return $result;
            }
        }
    }
    
    if($user_info = check_login($username, $password)){
        var_dump($user_info);
    }else{
        print 'loi';
    }
    
}



?>