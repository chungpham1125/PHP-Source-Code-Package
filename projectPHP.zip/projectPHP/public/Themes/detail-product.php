<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="public/css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/css/reset.css">
    <link rel="stylesheet" href="public/css/Fontawesome/css/all.min.css">
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="public/css/responsive.css">
    <title>Unitop Store</title>
</head>

<body>
    <div id="site">
        <div id="container">
            <div id="header-wp">
                <div class="wp-inner clearfix">
                    <a href="home.php" id="logo" class="float-left">UNITOP STORE</a>
                    <div id="btn-respon" class="float-right"><i class="fas fa-bars"></i></div>
                    <div id="cart-wp" class="float-right">
                        <a href="cart.php" id="btn-cart">
                            <span id="icon"><img src="public/images/icon-cart.png" alt=""></span>
                            <span id="num">5</span>
                        </a>
                    </div>
                </div>
            </div>
            <!-- ===================END-HEADER============= -->

            <div id="main-content-wp" class="detail-product-page">
                <div class="wp-inner clearfix">

                    <div id="sidebar" class="float-left">
                        <nav id="main-menu-wp">
                            <ul class="list-item">
                                <li class="active"><a href="home.php" title="Trang chủ">Trang chủ</a></li>
                                <li><a href="detail-news.php" title="Giới thiệu">Giới thiệu</a></li>
                                <li><a href="category-product" title="Điện thoại">Điện thoại</a></li>
                                <li><a href="category-product" title="Laptop">Laptop</a></li>
                                <li><a href="category-product" title="Máy tính">Máy tính</a></li>
                                <li><a href="detail-news" title="Liên hệ">Liên hệ</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- -----------End-Sidebar---------- -->

                    <div id="content" class="float-right">
                        <div class="session" id="info-product-wp">
                            <div class="session-detail clearfix">
                                <div class="thumb float-left">
                                    <img src="public/images/img-product.png" alt="">
                                </div>
                                <div class="detail float-right">
                                    <h3 class="title">Lenovo IdeaPad 100s 11IBY Z3735</h3>
                                    <p class="price">5.000.000đ</p>
                                    <p class="product-code">Mã sản phẩm: <span>VIETSOZ#123</span></p>
                                    <div class="desc-short">
                                        <h5>Mô tả sản phẩm</h5>
                                        <p>Lorem Ipsum chỉ đơn giản là một đoạn văn bản giả, được dùng vào việc trình bày và dàn trang phục vụ cho in ấn. Lorem Ipsum đã được sử dụng như một văn bản</p>
                                    </div>
                                    <div class="num-order-wp">
                                        <span>Số lượng:</span>
                                        <input type="text" id="num-order" name="num-order" value="1">
                                        <a href="cart.php" class="add-to-cart">Thêm giỏ hàng</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="session" id="desc-wp">
                                <div class="session-head">
                                    <h3 class="session-title">Chi tiết sản phẩm</h3>
                                </div>
                                <div class="session-detail">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                </div>
                            </div>
                    </div>
                    <!-- -----------End-Content---------- -->
                </div>
            </div>
            <!-- ===================END-MAIN CONTENT============= -->

            <div id="footer-wp">
                <div class="wp-inner">
                    <p id="copyright">© 2018 Copyright unitop.vn</p>
                </div>
            </div>
            <!-- ===================END-FOOTER============= -->
        </div>
        <div id="menu-respon">
            <a href="#" class="logo" title="Trang chủ">Vietsoz Shop</a>
            <div id="menu-respon-wp">
                <ul id="main-menu-respon">
                    <li>
                        <a href="home.php" title="Trang chủ">Trang chủ</a>
                    </li>
                    <li>
                        <a href="detail-news.php" title="Giới thiệu">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Điện thoại">Điện thoại</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Laptop">Laptop</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Máy tính bản">Máy tính bản</a>
                    </li>
                    <li>
                        <a href="detail-news.php" title="Liên hệ">Liên hệ</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ===================END-RESPONSIVE MENU============= -->
    </div>



    <script src="public/js/jquery-3.6.0.min.js"></script>
    <!-- <script src="public/js/bootstrap/bootstrap.min.js"></script> -->
    <script src="public/js/app.js"></script>
</body>

</html>