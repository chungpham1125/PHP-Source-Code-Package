<div id="footer-wp">
                <div class="wp-inner">
                    <p id="copyright">© 2018 Copyright unitop.vn</p>
                </div>
            </div>
            <!-- ===================END-FOOTER============= -->
        </div>
        <div id="menu-respon">
            <a href="" class="logo" title="Trang chủ">Vietsoz Shop</a>
            <div id="menu-respon-wp">
                <ul id="main-menu-respon">
                    <li>
                        <a href="" title="Trang chủ">Trang chủ</a>
                    </li>
                    <li>
                        <a href="?mod=pages&controller=index&action=detail&id=1" title="Giới thiệu">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="?mod=products&id=1" title="Điện thoại">Điện thoại</a>
                    </li>
                    <li>
                        <a href="?mod=products&id=2" title="Laptop">Laptop</a>
                    </li>
                    <li>
                        <a href="?mod=products&id=3" title="Máy tính bản">Máy tính bản</a>
                    </li>
                    <li>
                        <a href="?mod=pages&controller=index&action=detail&id=1" title="Liên hệ">Liên hệ</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ===================END-RESPONSIVE MENU============= -->
    </div>



    <script src="public/js/jquery-3.6.0.min.js"></script>
    <!-- <script src="public/js/bootstrap/bootstrap.min.js"></script> -->
    <script src="public/js/app.js"></script>
</body>

</html>