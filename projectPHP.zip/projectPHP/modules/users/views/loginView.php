<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?= base_url(); ?>">
    <title>Form Login</title>
    <link rel="stylesheet" href="public/css/reset.css">
    <link rel="stylesheet" href="public/css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
    <div id="wrapper">
        <form action="" method='POST' class="form-login">
            <h2 class="form-header">FORM ĐĂNG NHẬP</h2>
            <div class="form-group">
                <div class="form-icon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                <input type="text" name="username" value="<?php set_value('username'); ?>" class="form-input username" placeholder="Tên đăng nhập">
            </div>
            <?php form_error('username'); ?>
            <div class="form-group">
                <div class="form-icon"><i class="fa fa-key" aria-hidden="true"></i></div>
                <input type="password" name="password" class="form-input password js-password" placeholder="Mật khẩu">
                <div class="eye">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <?php form_error('password'); ?>
            <input type="submit" name='btn_login' value="ĐĂNG NHẬP" class="form-submit">
            <p class="form-checkbox"><label><input type="checkbox" name="remember_me" value="yes">Ghi nhớ đăng nhập</label></p>
            <?php form_error('account'); ?>
            <p class="mb-0 clearfix"><a href="?mod=users&action=register" class="float-right">Dang ky</a></p>
        </form>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="public/js/app.js"></script>

</html>