<?php get_header(); ?>
<div id="main-content-wp" class="thank-page">
    <div class="wp-inner clearfix">
        <?php get_sidebar(); ?>
        <div id="content" class="float-right">
            <div class="section" id="thank-wp">
                <div class="section-head">
                    <h3 class="section-title mt-4">Đặt hàng thành công</h3>
                </div>
                <div class="section-detail vh-100">
                    <p>Chúc mừng bạn đã đặt hàng thành công. Vui lòng kiểm tra địa chỉ <a href="https://mail.google.com/" title="Email">Email</a> để kiểm tra đơn hàng!</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>