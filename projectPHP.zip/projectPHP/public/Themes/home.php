<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="public/css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/css/reset.css">
    <link rel="stylesheet" href="public/css/Fontawesome/css/all.min.css">
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="public/css/responsive.css">
    <title>Unitop Store</title>
</head>

<body>
    <div id="site">
        <div id="container">
            <div id="header-wp">
                <div class="wp-inner clearfix">
                    <a href="" id="logo" class="float-left">UNITOP STORE</a>
                    <div id="btn-respon" class="float-right"><i class="fas fa-bars"></i></div>
                    <div id="cart-wp" class="float-right">
                        <a href="cart.php" id="btn-cart">
                            <span id="icon"><img src="public/images/icon-cart.png" alt=""></span>
                            <span id="num">5</span>
                        </a>
                    </div>
                </div>
            </div>
            <!-- ===================END-HEADER============= -->

            <div id="main-content-wp">
                <div class="wp-inner clearfix">

                    <div id="sidebar" class="float-left">
                        <nav id="main-menu-wp">
                            <ul class="list-item">
                                <li class="active"><a href="" title="Trang chủ">Trang chủ</a></li>
                                <li><a href="detail-news.php" title="Giới thiệu">Giới thiệu</a></li>
                                <li><a href="category-product" title="Điện thoại">Điện thoại</a></li>
                                <li><a href="category-product" title="Laptop">Laptop</a></li>
                                <li><a href="category-product" title="Máy tính">Máy tính</a></li>
                                <li><a href="detail-news" title="Liên hệ">Liên hệ</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- -----------End-Sidebar---------- -->

                    <div id="content" class="float-right">
                        <div class="session list-cat">
                            <div class="session-head">
                                <h3 class="session-title">Điện thoại</h3>
                            </div>
                            <div class="session-detail">
                                <ul class="list-item clearfix">
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="session list-cat">
                            <div class="session-head">
                                <h3 class="session-title">Laptop</h3>
                            </div>
                            <div class="session-detail">
                                <ul class="list-item clearfix">
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="session list-cat">
                            <div class="session-head">
                                <h3 class="session-title">Máy tính</h3>
                            </div>
                            <div class="session-detail">
                                <ul class="list-item clearfix">
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                    <li>
                                        <a href="detail-product.php" title="" class="thumb">
                                            <img src="public/images/img-product.png" alt="">
                                        </a>
                                        <a href="detail-product.php" class="title">Lenoco IdeaPad 1005</a>
                                        <p class="price">5.000.000đ</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- -----------End-Content---------- -->
                </div>
            </div>
            <!-- ===================END-MAIN CONTENT============= -->

            <div id="footer-wp">
                <div class="wp-inner">
                    <p id="copyright">© 2018 Copyright unitop.vn</p>
                </div>
            </div>
            <!-- ===================END-FOOTER============= -->
        </div>
        <div id="menu-respon">
            <a href="#" class="logo" title="Trang chủ">Vietsoz Shop</a>
            <div id="menu-respon-wp">
                <ul id="main-menu-respon">
                    <li>
                        <a href="home.php" title="Trang chủ">Trang chủ</a>
                    </li>
                    <li>
                        <a href="detail-news.php" title="Giới thiệu">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Điện thoại">Điện thoại</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Laptop">Laptop</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Máy tính bản">Máy tính bản</a>
                    </li>
                    <li>
                        <a href="detail-news.php" title="Liên hệ">Liên hệ</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ===================END-RESPONSIVE MENU============= -->
    </div>



    <script src="public/js/jquery-3.6.0.min.js"></script>
    <!-- <script src="public/js/bootstrap/bootstrap.min.js"></script> -->
    <script src="public/js/app.js"></script>
</body>

</html>