<?php

// Kiểm tran tên đăng nhập
function is_username($username,$min=6, $max=32, $pattern='/^[A-Za-z0-9_\.]{6,32}$/'){
    $num_char = strlen($username);
    // Kiểm tran độ dài tên đăng nhập
    if($num_char < $min || $num_char > $max){
        return array(
            'status' => false,
            'message' => 'Tên đăng nhập có độ dài quy định là 6 đến 32 ký tự',
        );
    }else{
        // Kiểm tra cá định dạng tên đăng nhập
        if(preg_match($pattern, $username)){
            return array(
                'status' => true,
            );
        }else{
            return array(
                'status' => false,
                'message' => 'Tên đăng nhập không đúng định dạng',
            );
        }
    }
}

// Kiểm tra mật khẩu
function is_password($password,$min=6, $max=32, $pattern='/^([A-Z]){1}([\w_\.!@#$%^&*()]+){5,31}$/'){
    $num_char = strlen($password);
    // Kiểm tran độ dài tên mật khẩu
    if($num_char < $min || $num_char > $max){
        return array(
            'status' => false,
            'message' => 'Mật khẩu có độ dài quy định là 6 đến 32 ký tự',
        );
    }else{
        // Kiểm tra cá định dạng tên mật khẩu
        if(preg_match($pattern, $password)){
            return array(
                'status' => true,
            );
        }else{
            return array(
                'status' => false,
                'message' => 'Mật khẩu không đúng định dạng',
            );
        }
    }
}

// Hàm thông báo lỗi trong quá trình nhập form
function form_error($field){
    if(isset($GLOBALS['errors'][$field])){
        echo "<p class='form-error'>{$GLOBALS['errors'][$field]}</p>";
    }
}

function set_value($field){
    global $$field;
    if(!empty($$field)){
        echo $$field;
    }
}

function show($rei){
    print $rei;
}

function check_is_login(){
    
    if(isset($_COOKIE['is_login']) && ($_COOKIE['is_login'] == true)){
        $_SESSION['is_login'] = $_COOKIE['is_login'];
        $_SESSION['user_login'] = $_COOKIE['user_login'];
    }

    $action = get_action();
    if($action != 'login' && $action != 'register'){
    if(!isset($_SESSION['is_login'])){
        redirect_to('Dang-nhap');
    }
}
}
