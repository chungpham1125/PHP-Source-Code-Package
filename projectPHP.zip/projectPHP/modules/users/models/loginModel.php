<?php

function check_login($username, $password){
    global $conn;
    //  Vô hiệu hóa những ký tự có khả năng tác động đến query SQL
    $username = mysqli_real_escape_string($conn,$username);
    $password = mysqli_real_escape_string($conn,$password);

    // Kiểm tra xem tên đăng nhập có tồn tại trong database không
    $result = db_num_rows("SELECT * FROM `tbl_users` WHERE `username` = '{$username}'");
    if(!($result >= 1)){
        // Nếu không tồn tại thì giá trị sẽ trả về 0
        return false;
    }else{
        // Nếu tồn tại thì kiểm tra password có chính xác không;
        $result = db_fetch_row("SELECT * FROM `tbl_users` WHERE `username` = '{$username}' AND `password` = '{$password}'");
        if(empty($result)){
            return false;
        }else{
            return $result;
        }
    }
}




?>