<?php get_header(); ?>
<!-- ===================END-HEADER============= -->

<div id="main-content-wp" class="detail-product-page">
    <div class="wp-inner clearfix">

        <?php get_sidebar(); ?>
        <!-- -----------End-Sidebar---------- -->

        <div id="content" class="float-right">
            <div class="session" id="checkout-wp">
                <div class="session-head">
                    <h3 class="session-title">Thanh toán</h3>
                </div>
                <?php if (!empty($list_product_cart)) { ?>
                    <div class="sesson-detail">
                        <div class="wrap clearfix">
                            <form action="?mod=cart&controller=index&action=thank" method="POST">
                                <div id="custom-info-wp" class="float-left">
                                    <h3 class="title">Thông tin khách hàng</h3>
                                    <div class="detail">
                                        <div class="field-wp clearfix">
                                            <label>Họ & tên</label>
                                            <input type="text" name="fullname" id="fullname">
                                        </div>
                                        <div class="field-wp clearfix">
                                            <label>Email</label>
                                            <input type="email" name="email" id="email">
                                        </div>
                                        <div class="field-wp clearfix">
                                            <label>Địa chỉ nhận hàng</label>
                                            <input type="text" name="address" id="address">
                                        </div>
                                        <div class="field-wp clearfix">
                                            <label>Số điện thoại</label>
                                            <input type="text" name="tel" id="tel">
                                        </div>
                                        <div>
                                            <label>Ghí chú</label>
                                            <textarea name="note"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div id="order-review-wp" class="float-right">
                                    <h3 class="title">Thông tin đơn hàng</h3>
                                    <div class="detail">
                                        <table class="shop-table">
                                            <thead>
                                                <tr>
                                                    <td>Sản phẩm(<?= $info_order['num_order']; ?>)</td>
                                                    <td>Tổng</td>
                                                    <input type="hidden" name="num_order" value="<?= $info_order['num_order']; ?>">
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($list_product_cart as $id => $item) { ?>
                                                    <tr class="cart-item">
                                                        <td class="product-name"><?= $item['product_title']; ?><strong class="product-quantity">x <?= $item['qty'] ?></strong></td>
                                                        <td class="product-total"><?= currency_format($item['sub_total']); ?></td>

                                                        <input type="hidden" name='products[<?= $id ?>][title]' value="<?= $item['product_title']; ?>">
                                                        <input type="hidden" name="products[<?= $id ?>][qty]" value="<?= $item['qty']; ?>">
                                                        <input type="hidden" name="products[<?= $id ?>][sub_total]" value="<?= currency_format($item['sub_total']); ?>">
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                            <tfoot>
                                                <tr class="order-total">
                                                    <td>Tổng đơn hàng</td>
                                                    <td><strong class="total-price"><?= currency_format($info_order['total']); ?></strong></td>

                                                    <input type="hidden" name="total" value="<?= currency_format($info_order['total']); ?>">
                                                </tr>
                                            </tfoot>
                                        </table>
                                        <div id="payment-checkout-wp">
                                            <ul id="payment-method">
                                                <li>
                                                    <input type="radio" name="payment-method" id="direct-payment" checked='checked' value="direct-payment">
                                                    <label for="direct-payment">Thanh toán tại cửa hàng</label>
                                                </li>
                                                <li>
                                                    <input type="radio" name="payment-method" id="payment-home" value="payment-home">
                                                    <label for="payment-home">Thanh toán tại nhà</label>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="place-order-wp">
                                            <button type="submit" name="btn_checkout">Đặt hàng</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php } else { ?>
                    <p class="text-danger">Không có sản phẩm. Quay lại <a href="?">Trang chủ</a></p>
                <?php } ?>
            </div>
        </div>
        <!-- -----------End-Content---------- -->
    </div>
</div>
<!-- ===================END-MAIN CONTENT============= -->

<?php get_footer(); ?>