<?php

function get_pagging($cat_id, $num_per_page, $base_url, $page = 0)
{
    // DỮ LIỆU
    // - Tổng số bản ghi
    $total_row = db_num_rows("SELECT * FROM `tbl_products` WHERE `cat_id` = {$cat_id}");
    // - Tổng số trang
    $num_page = ceil($total_row / $num_per_page);
    // - Trang hiện tại
    if ($page === 0) {
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    }
    $base_url = "{$base_url}&id={$cat_id}";

    // TẠO HÌNH
    if ($num_page > 1) {
        $str_pagging = '<ul class="list-pagenavi">';
        if ($page > 1) {
            $prev_page = $page - 1;
            $str_pagging .= "<li><a href=\"{$base_url}&page={$prev_page}\" data-id='{$cat_id}' data-page='{$prev_page}' class=\"prev-page\"><i class=\"fa fa-angle-left\"></i></a></li>";
        }
        for ($i = 1; $i <= $num_page; $i++) {
            $active = '';
            if ($page == $i)
                $active = 'class="active"';
            $str_pagging .= "<li {$active}><a href=\"{$base_url}&page={$i}\" data-id='{$cat_id}' data-page='{$i}'>$i</a></li>";
        }
        if ($page < $num_page) {
            $next_page = $page + 1;
            $str_pagging .= "<li><a href=\"{$base_url}&page={$next_page}\" data-id='{$cat_id}' data-page='{$next_page}' class=\"next-page\"><i class=\"fa fa-angle-right\"></i></a></li>";
        }
        $str_pagging .= '</ul>';

        return $str_pagging;
    }
    else {
        return false;
    }
}
/*
<ul id="list-pagenavi">
    <li class="active">
        <a href="">1</a>
    </li>
    <li>
        <a href="">2</a>
    </li>
    <li>
        <a href="">3</a>
    </li>
    <a href="" class="next-page"><i class="fa fa-angle-right"></i></a>
</ul>
*/
