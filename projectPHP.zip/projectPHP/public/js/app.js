// LOGIN FORM
$(document).ready(function() {
    $('.eye').click(function() {
        $(this).toggleClass('show');
        $(this).children('i').toggleClass('fa-eye fa-eye-slash');
        if ($(this).hasClass('show')) {
            $('.js-password').attr('type', 'text');
        } else {
            $('.js-password').attr('type', 'password');
        }
    });
});

//SHOPPING CART
$(document).ready(function() {
    $('#btn-respon').click(function(event) {
        $('#site').toggleClass('show-respon-menu');
        event.stopPropagation();
    });
    $('#container').click(function() {
        if ($('#site').hasClass('show-respon-menu')) {
            $('#site').removeClass('show-respon-menu');
        }
    });
});

// PAGGING IN MODULE HOME
$(document).ready(function() {
    $(document).on("click", ".js-pagenavi-wp .list-pagenavi li a", function() {
            var cat_id = $(this).attr('data-id');
            var page = $(this).attr('data-page');
            var data = { cat_id: cat_id, page: page };

            $.ajax({
                url: '?mod=home&controller=index&action=paggingAjax',
                method: 'POST',
                data: data,
                dataType: 'json',
                success: function(data) {
                    // Danh sách sản phẩm
                    // var list_product = data.html_list_product;
                    $('#list-cat-' + cat_id).children('.session-detail').html(data.html_list_product);

                    // Thanh phân trang
                    // var pagging = data.html_pagging;
                    // $('#pagenavi-wp-' + cat_id).find('.session-detail .list-pagenavi').remove();
                    // $('#pagenavi-wp-' + cat_id).children('.session-detail').append(data.html_pagging);
                    $('#pagenavi-wp-' + cat_id).children('.session-detail').html(data.html_pagging);
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                }
            });

            // alert('ok');
            return false;
        })
        // var eventObjElement = $('.js-pagenavi .list-pagenavi li a');
        // eventObjElement.click(function() {

    // });
});

//  UPDATE CART AJAX
$(document).ready(function() {
    $('.js-num-order').change(function() {
        var id = $(this).attr('data-id');
        var qty = $(this).val();
        var data = { id: id, qty: qty };
        $.ajax({
            url: '?mod=cart&controller=index&action=updateAjax',
            method: 'POST',
            data: data,
            dataType: 'json',
            success: function(data) {
                $('#sub-total-' + id).text(data.sub_total);
                $('#total-price span').text(data.total);
                $('#num').text(data.num_order);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });
    });
});