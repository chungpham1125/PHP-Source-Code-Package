<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="public/css/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/css/reset.css">
    <link rel="stylesheet" href="public/css/Fontawesome/css/all.min.css">
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="public/css/responsive.css">
    <title>Unitop Store</title>
</head>

<body>
    <div id="site">
        <div id="container">
            <div id="header-wp">
                <div class="wp-inner clearfix">
                    <a href="home.php" id="logo" class="float-left">UNITOP STORE</a>
                    <div id="btn-respon" class="float-right"><i class="fas fa-bars"></i></div>
                    <div id="cart-wp" class="float-right">
                        <a href="" id="btn-cart">
                            <span id="icon"><img src="public/images/icon-cart.png" alt=""></span>
                            <span id="num">5</span>
                        </a>
                    </div>
                </div>
            </div>
            <!-- ===================END-HEADER============= -->

            <div id="main-content-wp" class="detail-product-page">
                <div class="wp-inner clearfix">

                    <div id="sidebar" class="float-left">
                        <nav id="main-menu-wp">
                            <ul class="list-item">
                                <li class="active"><a href="home.php" title="Trang chủ">Trang chủ</a></li>
                                <li><a href="detail-news.php" title="Giới thiệu">Giới thiệu</a></li>
                                <li><a href="category-product" title="Điện thoại">Điện thoại</a></li>
                                <li><a href="category-product" title="Laptop">Laptop</a></li>
                                <li><a href="category-product" title="Máy tính">Máy tính</a></li>
                                <li><a href="detail-news" title="Liên hệ">Liên hệ</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- -----------End-Sidebar---------- -->

                    <div id="content" class="float-right">
                        <div class="session" id="checkout-wp">
                            <div class="session-head">
                                <h3 class="session-title">Thanh toán</h3>
                            </div>
                            <div class="sesson-detail">
                                <div class="wrap clearfix">
                                    <form action="" method="POST">
                                        <div id="custom-info-wp" class="float-left">
                                            <h3 class="title">Thông tin khách hàng</h3>
                                            <div class="detail">
                                                <div class="field-wp clearfix">
                                                    <label>Họ & tên</label>
                                                    <input type="text" name="fullname" id="fullname">
                                                </div>
                                                <div class="field-wp clearfix">
                                                    <label>Email</label>
                                                    <input type="email" name="email" id="email">
                                                </div>
                                                <div class="field-wp clearfix">
                                                    <label>Địa chỉ nhận hàng</label>
                                                    <input type="text" name="address" id="address">
                                                </div>
                                                <div class="field-wp clearfix">
                                                    <label>Số điện thoại</label>
                                                    <input type="text" name="tel" id="tel">
                                                </div>
                                                <div>
                                                    <label>Ghí chú</label>
                                                    <textarea name="note"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="order-review-wp" class="float-right">
                                            <h3 class="title">Thông tin đơn hàng</h3>
                                            <div class="detail">
                                                <table class="shop-table">
                                                    <thead>
                                                        <tr>
                                                            <td>Sản phẩm(1)</td>
                                                            <td>Tổng</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr class="cart-item">
                                                            <td class="product-name">Iphone 7 Gray<strong class="product-quantity">x 1</strong></td>
                                                            <td class="product-total">7,500,000đ</td>
                                                        </tr>
                                                        <tr class="cart-item">
                                                            <td class="product-name">Iphone 7 Gray<strong class="product-quantity">x 1</strong></td>
                                                            <td class="product-total">7,500,000đ</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr class="order-total">
                                                            <td>Tổng đơn hàng</td>
                                                            <td><strong class="total-price">17,200,000</strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                                <div id="payment-checkout-wp">
                                                    <ul id="payment-method">
                                                        <li>
                                                            <input type="radio" name="payment-method" id="direct-payment" checked='checked' value="direct-payment">
                                                            <label for="direct-payment">Thanh toán tại cửa hàng</label>
                                                        </li>
                                                        <li>
                                                            <input type="radio" name="payment-method" id="payment-home" value="payment-home">
                                                            <label for="payment-home">Thanh toán tại nhà</label>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="place-order-wp">
                                                    <button type="submit" name="checkout">Đặt hàng</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- -----------End-Content---------- -->
                </div>
            </div>
            <!-- ===================END-MAIN CONTENT============= -->

            <div id="footer-wp">
                <div class="wp-inner">
                    <p id="copyright">© 2018 Copyright unitop.vn</p>
                </div>
            </div>
            <!-- ===================END-FOOTER============= -->
        </div>
        <div id="menu-respon">
            <a href="#" class="logo" title="Trang chủ">Vietsoz Shop</a>
            <div id="menu-respon-wp">
                <ul id="main-menu-respon">
                    <li>
                        <a href="home.php" title="Trang chủ">Trang chủ</a>
                    </li>
                    <li>
                        <a href="detail-news.php" title="Giới thiệu">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Điện thoại">Điện thoại</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Laptop">Laptop</a>
                    </li>
                    <li>
                        <a href="category-product.php" title="Máy tính bản">Máy tính bản</a>
                    </li>
                    <li>
                        <a href="detail-news.php" title="Liên hệ">Liên hệ</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ===================END-RESPONSIVE MENU============= -->
    </div>



    <script src="public/js/jquery-3.6.0.min.js"></script>
    <!-- <script src="public/js/bootstrap/bootstrap.min.js"></script> -->
    <script src="public/js/app.js"></script>
</body>

</html>