<?php

function get_user_info_by_id($id){
    $id = (int)$id;
    $result = db_fetch_row("SELECT * FROM `tbl_users` WHERE `user_id` = {$id}");
    if(!empty($result)){
        return $result; 
    }else{
        return false;
    }
}



?>